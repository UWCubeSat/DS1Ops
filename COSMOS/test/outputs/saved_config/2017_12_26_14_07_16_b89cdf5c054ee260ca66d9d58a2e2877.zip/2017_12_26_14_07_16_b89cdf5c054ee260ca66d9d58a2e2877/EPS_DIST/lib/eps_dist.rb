# This class can be used in your scripts like so:
#   require 'eps_dist'
#   eps_dist = Eps_dist.new
#   eps_dist.utility
# For more information see the COSMOS scripting guide

class Eps_dist
  def utility
  end
end
